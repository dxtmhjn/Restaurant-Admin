//Constants http urls
export const apiURL = {
    BASE_URL: "http://localhost:7000/api/",
    SERVERBASE_URL: "https://juxtorder.herokuapp.com/api/",
   
  };