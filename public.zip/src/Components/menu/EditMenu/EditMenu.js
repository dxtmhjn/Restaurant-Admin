import React,{Component} from 'react';

class EditMenu extends Component{
    render(){
        return 
    }
}

export default EditMenu;