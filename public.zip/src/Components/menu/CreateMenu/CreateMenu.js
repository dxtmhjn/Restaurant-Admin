import React,{Component} from 'react';

class CreateMenu extends Component{
    render(){
        return (
        );
    }
}

export default CreateMenu;