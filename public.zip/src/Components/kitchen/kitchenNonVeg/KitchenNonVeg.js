import React,{Component} from 'react';

class KitchenNonVeg extends Component{
    render(){
        return (
            <div className="wrapper">
        <div className="card-container">
          <div className="card order-card">
            <div className="card-header">Table 5</div>
            <div className="card-body">
              <p>hi</p>
            </div>
          </div>
          <div className="card order-card">
            <div className="card-header">Table 15</div>
            <div className="card-body">
              <p>hi</p>
            </div>
          </div>
        </div>
      </div>
        );
    }
}

export default KitchenNonVeg;